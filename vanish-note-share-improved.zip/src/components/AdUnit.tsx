import React from 'react';

interface AdUnitProps {
  adSlot: string;
  adFormat?: 'auto' | 'horizontal' | 'vertical' | 'rectangle';
  className?: string;
}

export const AdUnit = ({ adSlot, adFormat = 'auto', className = '' }: AdUnitProps) => {
  // Determine dimensions based on ad format
  const getDimensions = () => {
    switch (adFormat) {
      case 'horizontal':
        return 'h-24 sm:h-28';
      case 'vertical':
        return 'h-64';
      case 'rectangle':
        return 'h-60';
      default: // auto
        return 'h-32 sm:h-40';
    }
  };
  
  return (
    <div className={`ad-container ${className} w-full`}>
      <div 
        className={`w-full ${getDimensions()} bg-muted/10 border border-dashed border-muted-foreground/30 rounded-lg flex flex-col items-center justify-center p-4`}
      >
        <div className="text-muted-foreground/70 text-sm">Sponsored Content</div>
        <div className="text-xs text-muted-foreground/50 mt-1">Ad ID: {adSlot}</div>
      </div>
    </div>
  );
};

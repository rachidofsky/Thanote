
// Redirect to HomePage
import { Navigate } from "react-router-dom";
import HomePage from "./HomePage";

const Index = () => {
  return <HomePage />;
};

export default Index;
